Challenge: You have options to change the name and pin when logged in.
