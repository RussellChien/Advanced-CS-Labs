Challenge 1: Have the ability to delete an employee by clicking on a button next to the profile. 
